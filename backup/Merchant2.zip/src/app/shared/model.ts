import { Time } from "@angular/common";

export class PassData{
    public messageType:string;
    public payload:any;
    constructor(msgType:string,data:any){
        this.messageType= msgType;
        this.payload= data;
    }
}
// export class Bizhour {
//     public date: Date;
//     public strdate: string;
//     public status: string;
//     public note: string;
//     public fromTime: Date;
//     public toTime: Date;

//     constructor(theDate: Date, thestrdate: string, theStatus: string, theNote: string, from: Date, to: Date) {
//         this.date = theDate;
//         this.strdate = thestrdate;
//         this.status = theStatus;
//         this.note = theNote;
//         this.fromTime = from;
//         this.toTime = to;
//     }
// }

export class AdUser {
    public id: Number;
    public name:string;
    public pWord:string;
    public active:boolean;
    public role:string;
    public country: string;
    public state: string;
    public city: string;
    public area: string;
    public location: string;
    public companyCode: string;
    public branchCode: string;
}

export class RefItems{
    public id:Number;
    public code:string;
    public description:string;
    public refType:string;
    public active:string;
}

export class Merchant{
        public id:Number;
        public country: string;
        public state: string;
        public city: string;
        public area: string;
        public location: string;
        public companyCode: string;
        public branchCode: string;
        public companyName: string;
        public displayName: string;
        public status: string;
        public companyType: string;
        public regNo: string;
        public gstNo: string;
        public merchantType: string;
        public deliveryType: string;
        public merchantCategory: string;
        public address1: string;
        public address2: string;
        public addrCity: string;
        public addrState:string;
        public postcode: string;
        public contactPIC: string;
        public email: string;
        public officePhone: string;
        public handphone: string;
        public website: string;
        public facebook: string;
        public latitude: string;
        public longitude: string;
        public aboutUs: string;
        public termAndCond: string;
        public deliveryFee: number;
        public remarks: string;
        public salesAgent: string;
        public subscriptionType: string;
        public itemProfit: number;
        public halalCert: string;
        public taxGroup: string;
        public taxPercent: number;
        public updateDate: Date;
        public updateBy: string;
        public createDate: Date;
        public createBy: string;
}

export class RegisterProfile {
    public id:Number;
    public registerNo:string;
    public registerDate:Date;
    public companyName: string;
    public displayName: string;
    public regNo: string;
    public address1: string;
    public address2: string;
    public addrCity: string;
    public addrState:string;
    public postcode: string;
    public contactPIC: string;
    public email: string;
    public officePhone: string;
    public handphone: string;
    public website: string;
    public facebook: string;
    public updateDate: Date;
    public updateBy: string; 
    public aboutUs: string;
}

export class MechantItem {
    public id:Number;
    public country: string;
    public state: string;
    public city: string;
    public area: string;
    public location: string;
    public companyCode: string;
    public branchCode: string;
    public itemCode: string;
    public merchantItemCode: string;
    public itemStatus: string;
    public itemName: string;
    public itemDetail: string;
    public itemDetailCN: string;
    public itemDetailBM: string;
    public itemType: string;
    public itemTag: string;
    public itemCategory: string;
    public subCategory1: string;
    public subCategory2: string;
    public subCategory3: string;
    public subCategory4: string;
    public displayImage:string;
    public setEffective: boolean;
    public effectiveFrom: Date;
    public effectiveTo: Date;
    public prepareTime: string;
    public priceType: string;
    public taxName: string;
    public taxValue: number;
    public menuCategory: string;
    public itemProfit: number;
    public updateDate: Date;
    public updateBy: string;
    public createDate: Date;
    public createBy: string;
    public costPrice:number;
    public costWithGST:number;
    public costTaxAmount:number;
    public sellingPrice:number;
    public priceWithGST:number;
    public taxAmount:number;
    public options:ItemOption[];
}

export class ItemOption {
    public id:number;
    public itemCode:string;
    public optionCode:string;
    public merchantOptionCode:string;
    public optionType:string;
    public optionName:string;
    public optionNameCN:string;
    public optionNameBM:string;
    public imageName:string;
    public costPrice:number;
    public costWithGST:number;
    public costTaxAmount:number;
    public sellingPrice:number;
    public priceWithGST:number;
    public taxAmount:number;
    public active:boolean;
    public updateDate:Date;
    public updateBy:string;
    public createDate:Date;
    public createBy:string;
}

export class MerchantItemImage {
    public id:number;
    public itemCode:string;
    public imageName:string;   
    public defaultImage:boolean; 
}

export class ItemImages{
    public imageUrl:string;
    public imagename:string;
    public uploadedOn:Date;
    public default:boolean;
}

export class UserInfo
{
    public name:string;
    public fullname;
    public access:string;;
    public country:string;
    public state:string;
    public city:string;
    public area:string;
    public location:string;
    public companyCode:string;
    public branchCode:string;
    public role:string;
}

export class BizHour {
    public id: Number;
    public country: string;
    public state: string;
    public city: string;
    public area: string;
    public location: string;
    public companyCode: string;
    public branchCode: string;
    public workDate: Date;
    public dayType: string;
    public fromHour: Date;
    public toHour: Date;
    public repeatType: string;
    public dayName: string;
    public note: string;
    public updateDate: Date;
    public updateBy: string;
    public createDate: Date;
    public createBy: string;
}

export class ItemImageInfo
{
    public itemCode:string;
    public itemName:string;
    public optionCode:string;
    public optionType:string;
    public optionName:string;
    public imageName:string;
    public priceType:string;
    public costPrice:number;
    public costWithGST:number;
    public costTaxAmount:number;
    public sellingPrice:number;
    public priceWithGST:number;
    public taxAmount:number;
   
  
}