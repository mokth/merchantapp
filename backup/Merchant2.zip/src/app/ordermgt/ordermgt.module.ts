import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OrdermgtRoutingModule } from './ordermgt-routing.module';
import { OrdercompComponent } from './ordercomp.component';

@NgModule({
  imports: [
    CommonModule,
    OrdermgtRoutingModule
  ],
  declarations: [OrdercompComponent]
})
export class OrdermgtModule { }
