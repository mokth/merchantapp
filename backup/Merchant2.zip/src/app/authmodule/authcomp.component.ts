import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-authcomp',
  templateUrl: './authcomp.component.html',
  styleUrls: ['./authcomp.component.css']
})
export class AuthcompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
