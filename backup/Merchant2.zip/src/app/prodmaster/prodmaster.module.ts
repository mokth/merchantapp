import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProdmasterRoutingModule } from './prodmaster-routing.module';

@NgModule({
  imports: [
    CommonModule,
    ProdmasterRoutingModule
  ],
  declarations: []
})
export class ProdmasterModule { }
