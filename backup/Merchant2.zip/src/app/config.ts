export var config = {
    "apiUrl":'http://13.228.130.195/galaCoreAPI/',
    "apiUrl-dev":'http://localhost:55038/',
    "title":"ERP MOBILE",
    "imagepathdd":"assets",
    "imagepath":"merchant/assets",

  }