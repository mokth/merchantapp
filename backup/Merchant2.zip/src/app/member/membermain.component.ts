import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-membermain',
  templateUrl: './membermain.component.html',
  styleUrls: ['./membermain.component.css']
})
export class MembermainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
